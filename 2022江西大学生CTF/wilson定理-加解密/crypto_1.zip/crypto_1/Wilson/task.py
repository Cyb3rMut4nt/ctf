from os import urandom
from gmpy2 import next_prime
from Crypto.Util.number import getPrime, bytes_to_long

p = getPrime(512)
q = next_prime(p)
f = open('flag.txt', 'rb')
flag = bytes_to_long(f.read() + urandom(80))
f.close()

N = 1
a = p * q
for i in range(1, p):
    N = (N * i) % a
e = 65537
m = N * flag % a
c = pow(m, e, a)
f = open('Encode.txt', 'w')
f.write(f'a = {a}\n')
f.write(f'c = {c}\n')
f.close()
