http://ip:port
采用浏览器访问获取shell吧
