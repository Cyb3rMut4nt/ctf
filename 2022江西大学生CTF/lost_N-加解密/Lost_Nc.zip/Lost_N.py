import gmpy2
from Crypto.Util.number import *
# part1
flag = b'SangFor{}'
d = getPrime(435)
count = 5
while count > 0:
    p = getPrime(512)
    q = getPrime(512)
    n = p * q
    phi = (p-1) * (q-1)
    e = gmpy2.invert(d, phi)
    print('c =', pow(bytes_to_long(flag), e, n))
    print('n =', n)
    print('e =', e)
    count -= 1

# part2
p = getPrime(1024)
q = getPrime(1024)
n = p * q
e = 0x10001
s = pow(900*p - 218*q, n-p-q, n)
c = pow(last_n, e, n)
print('n =', n)
print('c =', c)
print('s =', s)
