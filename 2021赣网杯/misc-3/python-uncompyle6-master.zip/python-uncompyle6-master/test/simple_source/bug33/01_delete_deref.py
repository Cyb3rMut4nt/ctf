def a():
    del y
    def b():
        return y
