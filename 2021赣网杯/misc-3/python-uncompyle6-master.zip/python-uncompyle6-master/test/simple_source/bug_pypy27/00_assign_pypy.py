# From PyPy 2.6.1 datetime
# PyPy has simpler handling of assign3 and assign2
i, n = 0, 1
a, b, c = 1, 2, 3
