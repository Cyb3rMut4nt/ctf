# Bug from Python 3.4 ftplib
cls_or_self, *rest = args
a, *b, c = args
