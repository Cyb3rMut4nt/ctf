# From Python 2.7 ihooks.py
def ensure_fromlist(self, fromlist):
    for sub in fromlist:
        if sub:
            if not recursive:
                try:
                    all = 5
                except AttributeError:
                    pass
                else:
                    all = 6
            continue
