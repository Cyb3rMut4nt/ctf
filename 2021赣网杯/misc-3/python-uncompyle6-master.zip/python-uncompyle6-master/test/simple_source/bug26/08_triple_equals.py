# From Python 2.6 aifc.py
# Bug was handling triple ==
# Fixed by removing some COME_FROMs inside
if expon == himant == lomant == 0:
    f = 0.0
else:
    f = 1.1
