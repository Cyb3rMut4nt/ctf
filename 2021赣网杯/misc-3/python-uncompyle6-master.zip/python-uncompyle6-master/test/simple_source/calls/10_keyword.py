# Tests:
#
#   call_stmt ::= expr POP_TOP
#   build_list ::= expr expr BUILD_LIST_2
#   kwarg ::= LOAD_CONST expr
#   call_function ::= expr expr kwarg kwarg CALL_FUNCTION_513

sorted([1,2], reverse=True, key=None)
