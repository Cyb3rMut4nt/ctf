#!/bin/bash
STOP_ONERROR=0  ./runun33.sh 'test_[a-b]*.py'
STOP_ONERROR=0  ./runun33.sh 'test_[a-b]*.py'
