#!/usr/bin/python3 -u 
from secret import f, k, i
from Crypto.PublicKey import ElGamal as c
from Crypto.Util.number import bytes_to_long as t


d = []
k = c.construct(k)
z = 62108754904287032821971381232956885052769068054607609275042182309040123248979381249587936612457114553082984085473302992025047447258976388732555778861072247007820649687902442248057135518944999341930795894210983350234495243479752339988814594642849784670120645449023408944862789781184747815252870664480503695731

def _(_):
    if type(_) == str:
        _ = _.encode()
    return pow(k.g, t(_), k.p)

def a():
    return f"({k.p}, {k.g}, {k.y})"

def b():
    from random import randint as a, choice as b
    d.append(k._encrypt(_(b(i)), a(1, k.p-1)))
    return d[-1][1]

def c(b):
    try:
        for a, __ in d:
            c = k._decrypt((a, b))
            if c == z:
                return f
            e = [d for d in i if _(d) == c]
            if e:
                return e[0]
    except Exception as e:
        pass
    return "not_found"

def O():
    print("1. a")
    print("2. b")
    print("3. c")
    print("4. d")

if __name__ == '__main__':
    print('数字中国')
    while True:
        O()
        r = int(input('> '))
        if r == 1:
            r = a()
        elif r == 2:
            r = b()
        elif r == 3:
            r = c(int(input('b> ')))
        elif r == 4:
            break
        print(r)